/*
 * jPipette 1.0.1
 *
 * jQuery Plugin to pick colors from images
 *
 * Copyright (c) 2011 Ayman Teryaki
 * Havalite CMS (http://havalite.com/)
 * MIT style license, FREE to use, alter, copy, sell, and especially ENHANCE
 *
 *
 */
 
 var mult = 4;	

function rgb2hex(rgb){
 rgb = rgb.match(/(\d+),\s*(\d+),\s*(\d+)/);
 return "#" +
  ("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[3],10).toString(16)).slice(-2);
}
var jpipette_win = '<div id="draggable"><span id="jpipette_title">jPipette</span><div id="jpipette_content"><table width="100%" border="0" cellspacing="0" cellpadding="1"><tr><td colspan="2"><div align="center"><input type="image" class="my_button" name="buttonName" value="Off" src="images/pipette-icon.png" /></div></td><td rowspan="2" id="jpipette_color"></td></tr><tr><td rowspan="2"><img src="images/cat_magnifier.png" width="21" height="21" border="0"></td><td rowspan="2"><input type="image" name="plusBttton" src="images/plus.png" onClick="mult = mult*2;" /><br><input type="image" name="plusBttton" src="images/minus.png" onClick="mult = mult/2;" /></td></tr><tr><td><input type="text" id="hex_color" name="hex_color"><br><input type="text" id="rgb_color" name="rgb_color"></td></tr></table></div></div>';

$(document).ready( function(){
	$('body').append(jpipette_win);
	$("#draggable").draggable();
	$(".my_button").toggle(function(){
		$(this).val("On");
			$('img').css({ 'cursor':'crosshair' });
			$('#zoomer').css({ 'display': 'block' });
		},function(){
			$(this).val("Off"); $('img').css({ 'cursor':'auto' });
			$('#zoomer').css({ 'display': 'none' });
	});
	
	$('img').mousedown(function(event){
		if($('.my_button').val() == 'On'){
			var img = $(this).attr("src");
			var x = event.pageX - this.offsetLeft;
			var y = event.pageY - this.offsetTop;
			$.post("pipette.php", { img:img, x:x, y:y }, function(data){ 
				$('#jpipette_color').css('background', 'rgb(' + data + ')'); 
				$('#hex_color').val(rgb2hex(data));
				$('#rgb_color').val(data);
			});
		}
	});
	
	$('img').mousemove(function(event){
		//var outWidth = $(this).outerWidth();
		var img = $(this).attr("src");
		var mx = event.pageX;
		var my = event.pageY;
		var x = mx - this.offsetLeft;
		var y = my - this.offsetTop;
		var w = $(this).width();
		var h = $(this).height();
		
		//$('#zoomer').html(x + ',' + y + '<br>' + w + 'x' + h);
		$('#zoomer').css({ 'background':'url('+img+') -'+((x*mult)-49)+'px -'+((y*mult)-49)+'px' });
		$('#zoomer').css({ 'background-size': ' '+ (w*mult) + 'px ' + (h*mult) + 'px' });
		$('#zoomer').css({ 'top' : (my-110) + 'px' });
		$('#zoomer').css({ 'left' : (mx-110) + 'px' });
	});
});


