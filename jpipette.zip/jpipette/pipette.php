<?php

$img = $_POST['img'];
$x = $_POST['x'];
$y = $_POST['y'];

if($img and $x and $y){
	$type = substr($img, -4);
	$type = str_replace('.', '', $type);
	
	if($type== 'jpeg' or $type=='jpg') $im = imagecreatefromjpeg($img);
	elseif($type== 'gif'){
		$imgObj = imagecreatefromgif($img);
		imagejpeg($imgObj, 'ssgimg.jpg', 100);
		imagedestroy($imgObj);
		$im = imagecreatefromjpeg('ssgimg.jpg');
	}
	elseif($type== 'png'){ 
		$im = imagecreatefrompng($img); 		
	}

	$rgb = imagecolorat($im, $x, $y);
	$r = ($rgb >> 16) & 0xFF;
	$g = ($rgb >> 8) & 0xFF;
	$b = $rgb & 0xFF;
	
	echo $r.','.$g.','.$b;
}
?>